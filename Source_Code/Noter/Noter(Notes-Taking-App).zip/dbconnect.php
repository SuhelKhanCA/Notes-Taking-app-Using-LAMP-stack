<?php
$servername='localhost';
$username='id19877462_noter1';
$password='Hhhrocks001@';
$database='id19877462_noter';
$connection=mysqli_connect($servername,$username,$password,$database);
?>